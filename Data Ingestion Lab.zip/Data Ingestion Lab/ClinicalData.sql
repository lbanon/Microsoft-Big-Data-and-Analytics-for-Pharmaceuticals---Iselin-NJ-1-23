/****** Object:  Table [dbo].[ClinicalData]    Script Date: 1/19/2019 11:05:33 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ClinicalData](
	[Year] [smallint] NULL,
	[LocationAbbr] [varchar](255) NULL,
	[LocationDesc] [varchar](255) NULL,
	[Datasource] [varchar](255) NULL,
	[PriorityArea1] [varchar](255) NULL,
	[PriorityArea2] [varchar](255) NULL,
	[PriorityArea3] [varchar](255) NULL,
	[PriorityArea4] [varchar](255) NULL,
	[Category] [varchar](255) NULL,
	[Topic] [varchar](255) NULL,
	[Indicator] [varchar](255) NULL,
	[Data_Value_Type] [varchar](255) NULL,
	[Data_Value_Unit] [varchar](255) NULL,
	[Data_Value] [numeric](18, 2) NULL,
	[Data_Value_Alt] [numeric](18, 2) NULL,
	[Data_Value_Footnote_Symbol] [varchar](255) NULL,
	[Data_Value_Footnote] [varchar](255) NULL,
	[Confidence_Limit_Low] [varchar](255) NULL,
	[Confidence_Limit_High] [numeric](18, 2) NULL,
	[Break_Out_Category] [varchar](255) NULL,
	[Break_out] [varchar](255) NULL,
	[CategoryID] [varchar](255) NULL,
	[TopicID] [varchar](255) NULL,
	[IndicatorID] [varchar](255) NULL,
	[Data_Value_TypeID] [varchar](255) NULL,
	[BreakoutCategoryID] [varchar](255) NULL,
	[BreakOutID] [varchar](255) NULL,
	[LocationID] [tinyint] NULL,
	[GeoLocation] [varchar](255) NULL
) ON [PRIMARY]
GO


